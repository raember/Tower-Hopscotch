package ch.zhaw.psit.towerhopscotch.models.tiles;

class UnknownTile extends Tile {

    UnknownTile(int id) {
        super("unknown", id);
    }
}
