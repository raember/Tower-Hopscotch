package ch.zhaw.psit.towerhopscotch.models.tiles;


class TempleTile extends Tile {

    TempleTile(int id) {
        super("temple", id);
    }
}
