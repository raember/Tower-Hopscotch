package ch.zhaw.psit.towerhopscotch.models.enums;

/**
 * The different directions on the map
 */
public enum Direction {
    LEFT, RIGHT, UP, DOWN
}
