package ch.zhaw.psit.towerhopscotch.models.enums;

/**
 * The different type of layers
 */
public enum LayerType {
    HELL, EARTH, HEAVEN
}
