package ch.zhaw.psit.towerhopscotch.models.tiles;


class StoneTile extends Tile {

    StoneTile(int id) {
        super("stone", id);
    }
}
